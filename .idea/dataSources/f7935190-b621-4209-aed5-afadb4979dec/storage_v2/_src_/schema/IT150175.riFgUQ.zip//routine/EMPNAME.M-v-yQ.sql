CREATE FUNCTION EMPNAME(empnr emp.empno%type, code number) RETURN VARCHAR2 AS 

ret_name emp.ename%type;
sal number;
comm number;

BEGIN
  if code != 1 and code != 2 then
    return 'DUCK U DANNINGER';
  end if;
  select ename,sal,comm into ret_name,sal,comm from emp where empnr = empno;
  if ret_name is null then
  return 'Unbekannt bekommt null';
  end if;
  
  if code = 1 then
    return ret_name ||' bekommt '|| (sal+nvl(comm,0));
  else
    return ret_name ||' bekommt '|| sal;
  end if;
  RETURN NULL;
END EMPNAME;
/

