CREATE FUNCTION EMPCOUNT(deptnr DEPT.DEPTNO%type) RETURN number AS 

count2 number;

BEGIN
  select count(*) into count2 from emp where DEPTNO = deptnr group by dePtNo;
  
  RETURN count2;
END EMPCOUNT;
/

