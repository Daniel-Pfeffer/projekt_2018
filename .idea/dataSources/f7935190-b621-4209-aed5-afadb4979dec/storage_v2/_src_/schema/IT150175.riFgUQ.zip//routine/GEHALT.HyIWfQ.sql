CREATE FUNCTION GEHALT(empNr EMP.EMPNO%type) RETURN emp.sal%type AS 
  returnGehalt emp.sal%type;
  sal emp.sal%type;
  comm emp.comm%type;
BEGIN
  select sal,nvl(comm,0) into sal,comm from emp where empno = empNr;
  returnGehalt := sal+comm;
  RETURN returnGehalt;
END GEHALT;
/

