CREATE FUNCTION DIFF(empnr emp.empno%TYPE, empnr2 EMP.EMPNO%type) RETURN VARCHAR2 AS 
  returnVal number;
  name1 EMP.ENAME%type;
  name2 EMP.ENAME%type;
  hire1 emp.hiredate%type;
  hire2 emp.hiredate%type;

BEGIN
  select hiredate,ename into hire1,name1 from emp where empno = empnr;
  select hiredate,ename into hire2,name2 from emp where empno = empnr2;
  
  if hire1 = null then
    return 'Error user '||empnr||' doesnt exist';
  end if;
  if hire2 = null then
    return 'Error user '||empnr||' doesnt exist';
    end if;
  
  if hire1>hire2 then
    return name1||'  '||(hire1-hire2)||' Tage vor '||name2;
  else
    return name2 || '  ' || (hire2-hire1) || ' Tage vor ' || name1;
    end if;
  
END DIFF;
/

